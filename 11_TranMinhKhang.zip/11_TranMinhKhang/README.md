11_Trần Minh Khang:
Lớp WE24-01

Mô tả project:
-Website UI/UX nâng cao
-4 trang 
-Animation + layout nâng cao

Công nghệ:
-HTML5, CSS3, JS
-AOS/ @keyframe/Swiper

Link demo (GitHub Pages):http://localhost/11_TranMinhKhangMiniProject2_TranMinhKhang/index.html
